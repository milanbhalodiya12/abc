const socket = io('http://localhost:8000');

// Get DOM elements in respective JS variables
const sendForm = document.getElementById('send-form');
const msgInput = document.getElementById('message');
const messageContainer = document.querySelector('.msg-container');

// Audio that will be play on receiving messages
const audio = new Audio('ting.mp3');

// Function which will append event info to the container
const append = (message, position) => {
    const messageElement = document.createElement('div');
    messageElement.innerHTML = message;
    messageElement.classList.add('message');
    messageElement.classList.add(position);
    messageContainer.appendChild(messageElement); // Corrected from appendChild to messageContainer
    if (position === 'left') {
        audio.play();
    }
}

// Ask new user for his name
const username = prompt('Enter your name:');
socket.emit('new-user-joined', username);

// If new user joins, receive his message from the server
socket.on('user-joined', (name) => {
    if (name !== '') {
        append(`${name} joined the chat`, 'right');
    }
});

// If new message is received, receive it from the server
socket.on('receive-message', (data) => {
    append(`${data.name} : ${data.message}`, 'left');
});

// If user leaves, receive it from the server
socket.on('user-left', (name) => {
    append(`${name} left the chat`, 'right');
});

// When form is submitted, send message to the server
sendForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const message = msgInput.value;
    append(`You : ${message}`, 'right');
    socket.emit('send-message', message);
    msgInput.value = '';
});