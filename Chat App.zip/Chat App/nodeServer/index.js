const { Server } = require('socket.io');
const io = new Server(8000, {
    cors: {
        origin: "*", // Allow all origins for testing, you can restrict it later
        methods: ["GET", "POST"]
    }
});

const users = {};

io.on('connection', (socket) => {
    console.log("A user connected");

    socket.on('new-user-joined', (name) => {
        users[socket.id] = name;
        socket.broadcast.emit('user-joined', name);
    });

    socket.on('send-message', (message) => {
        socket.broadcast.emit('receive-message', { message: message, name: users[socket.id] });
    });

    socket.on('disconnect', () => {
        if (users[socket.id]) {
            const name = users[socket.id];
            delete users[socket.id];
            socket.broadcast.emit('user-left', name);
        }
    });
});
